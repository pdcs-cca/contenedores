DIRECTORY: ./exec
___________________________________________________________

The contents of this directory contain all the HYSPLIT
executables which are created by running compile.sh 
(in ./scripts) or the Makefile (in ./source). The hysplit 
library should be created first.

-----------------------------------------------------------

run_mpi.sh	- sample script that needs to be customized
		  to run the multiprocessor HYSPLIT 
